# 糕糕の27歲旅行 ♡

## 本機預覽
1. 解壓縮資料夾。
2. 用瀏覽器打開 `index.html` 即可預覽（手機也可以）。

## 加入你們的照片
把兩張照片放進 `images` 資料夾，檔名分別改成：
- `couple-1.jpg`
- `couple-2.jpg`

然後在 `index.html` 的 `.photo-frame` 區塊中，將兩個預覽框的 `<img>` 改成：
`<img src="images/couple-1.jpg" class="ready" alt="我們的合照一">`
第二張則使用 `images/couple-2.jpg`。同時移除該框內的選檔提示文字與 input，或保留也可以。

注意：網站上的「選照片預覽」只會在目前裝置顯示，不會自動上傳到公開網站。若要讓收件人也看到照片，請把照片檔放進 `images` 資料夾後一併發布。

## 發布成公開網址（GitHub Pages）
1. 登入 GitHub，建立一個新的 Public repository，例如 `gaogao-27-trip`。
2. 上傳 `index.html` 和整個 `images` 資料夾（以及你放進去的照片）。
3. 進入 repository 的 Settings → Pages。
4. 在 Build and deployment 選 `Deploy from a branch`。
5. Branch 選 `main`、資料夾選 `/ (root)`，按 Save。
6. 等待部署完成，GitHub 會顯示公開網址。

## 備註
- 背景音樂是網頁內即時合成的輕柔旋律，不需另外下載音檔；必須由訪客點擊後才會播放。
- 日期與行程是目前規劃草案，實際出發前請重新確認天氣、道路、步道開放狀況及日出時間。
